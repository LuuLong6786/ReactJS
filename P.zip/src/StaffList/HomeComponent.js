import React from "react";

function HomeComponent() {
  return (
    <div
      className="container"
      style={{
        textAlign: "center",
        fontSize: "50px",
        marginTop: "10%",
        marginBottom: "10%",
      }}
    >
      WELCOME TO MY FIRST STAFF MANAGEMENT APPLICATION V.10
    </div>
  );
}

export default HomeComponent;
