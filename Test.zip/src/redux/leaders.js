import { LEADERS } from "../shared/leaders";
import * as ActionTypes from "./ActionTypes";

export const Leaders = (
  state = {
    errMess: null,
    leaders: [],
  },
  action
) => {
  switch (action.type) {
    case ActionTypes.ADD_LEADERS:
      return {
        ...state,
        leaders: action.payload,
        errMess: null,
      };

    case ActionTypes.LEADERS_FAILED:
      return {
        ...state,
        leaders: [],
        errMess: action.payload,
      };
    default:
      return state;
  }
};
