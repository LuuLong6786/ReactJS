export const ADD_COMMENT = "ADD_COMMENT";
// Create a ActionType pattern
// Mục đích: để Reducer phan biệt được các Action
// Giá trị cho trường type của action dc mô tả dưới dạng String - viết hoa (should be - style code phổ biến)
export const DISHES_LOADING = "DISHES_LOADING";
export const DISHES_FAILED = "DISHES_FAILED";
export const ADD_DISHES = "ADD_DISHES";
